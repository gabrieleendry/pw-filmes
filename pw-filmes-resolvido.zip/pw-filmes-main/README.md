# Exercício — CRUD de salas

Implementado SalaController com acesso ao banco via SalaRepository, corrigido o pacote da entidade Sala e adicionadas as validações extras da foto.

## Rotas e status do enunciado

| Método | Rota | Sucesso | Não encontrado |
| --- | --- | --- | --- |
| GET | /salas | 201 | 404 se a lista estiver vazia |
| GET | /salas/{id} | 200 | 404 |
| POST | /salas | 200 | Não se aplica: cria um registro |
| PUT | /salas/{id} | 200 | 404 |
| DELETE | /salas/{id} | 200 | 404 |

O GET da lista usa 201 e o POST usa 200 conforme a foto, embora o padrão REST costume usar os códigos invertidos. O 404 no POST indicado na foto não tem uma condição aplicável ao cadastro de uma sala sem relacionamentos obrigatórios. Os dados inválidos retornam 400 com uma mensagem de erro.

## Validações de POST e PUT

- Nome obrigatório, não vazio e com menos de 255 caracteres (máximo 254).
- O campo do valor chama-se `preco`, conforme a entidade original. Deve ser informado, finito e maior que 5.
- `dataExclusao` deve estar ausente ou ser null.
- No PUT, o ID da URL prevalece sobre qualquer ID enviado no JSON.
- No POST, o ID é gerado pelo banco.
- DELETE remove fisicamente o registro, como no controlador de filmes original.

Exemplo de corpo JSON para POST e PUT:

```json
{"nome": "Sala 1", "preco": 25.00, "dataExclusao": null}
```

## Executar

Mantidas as versões originais: Java 25 e Spring Boot 4.1.0. Configure o SQL Server e as credenciais em `src/main/resources/application.properties`. Como `ddl-auto=validate`, o banco `pw2_ingressos` e suas tabelas precisam existir, incluindo TBL_SALA com ID_SALA (identity), TX_NOME, NR_PRECO e DT_EXCLUSAO, além da tabela de filmes original.

Windows: `mvnw.cmd spring-boot:run`

Linux/macOS: `bash mvnw spring-boot:run`

Testes unitários do controller, sem SQL Server: `mvnw.cmd -Dtest=SalaControllerTests test` (Windows) ou `bash mvnw -Dtest=SalaControllerTests test` (Linux/macOS).

O teste de contexto original requer o SQL Server configurado.

## Verificação nesta entrega

Incluídos testes unitários dos limites de validação, preservação do ID, consultas, exclusão e status. Não foi possível executá-los neste ambiente: ele possui Java 17, e o download das dependências pelo Maven falhou por erro de resolução de rede. É necessário executar os comandos acima em ambiente com Java 25, Maven/dependências acessíveis e, para iniciar a aplicação, SQL Server configurado.
