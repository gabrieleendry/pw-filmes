package br.com.etec.ingresso.controller;

import br.com.etec.ingresso.entity.Sala;
import br.com.etec.ingresso.repository.SalaRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/salas")
public class SalaController {

    private final SalaRepository salaRepository;

    public SalaController(SalaRepository salaRepository) {
        this.salaRepository = salaRepository;
    }

    @GetMapping
    public ResponseEntity<List<Sala>> listar() {
        var salas = salaRepository.findAll();
        if (salas.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        // Status solicitado no enunciado da atividade.
        return ResponseEntity.status(HttpStatus.CREATED).body(salas);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Sala> buscarPorId(@PathVariable("id") Long id) {
        return salaRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<?> cadastrar(@RequestBody Sala sala) {
        String erro = validar(sala);
        if (erro != null) {
            return ResponseEntity.badRequest().body(Map.of("erro", erro));
        }
        // O identificador e gerado pelo banco, nunca escolhido no POST.
        sala.setId(null);
        return ResponseEntity.ok(salaRepository.save(sala));
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> atualizar(@RequestBody Sala sala,
                                       @PathVariable("id") Long id) {
        String erro = validar(sala);
        if (erro != null) {
            return ResponseEntity.badRequest().body(Map.of("erro", erro));
        }
        var existente = salaRepository.findById(id);
        if (existente.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        var atualizada = existente.get();
        atualizada.setNome(sala.getNome());
        atualizada.setPreco(sala.getPreco());
        atualizada.setDataExclusao(null);
        return ResponseEntity.ok(salaRepository.save(atualizada));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletar(@PathVariable("id") Long id) {
        var existente = salaRepository.findById(id);
        if (existente.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        salaRepository.delete(existente.get());
        return ResponseEntity.ok().build();
    }

    private String validar(Sala sala) {
        if (sala == null || sala.getNome() == null || sala.getNome().isBlank()) {
            return "O nome deve ser informado.";
        }
        if (sala.getNome().codePointCount(0, sala.getNome().length()) >= 255) {
            return "O nome deve ter menos de 255 caracteres.";
        }
        if (sala.getPreco() == null || !Double.isFinite(sala.getPreco())
                || sala.getPreco() <= 5) {
            return "O preco deve ser maior que 5 reais.";
        }
        if (sala.getDataExclusao() != null) {
            return "A data de exclusao deve ser nula.";
        }
        return null;
    }
}
