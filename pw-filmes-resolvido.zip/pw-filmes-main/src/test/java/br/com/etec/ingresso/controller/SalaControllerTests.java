package br.com.etec.ingresso.controller;

import br.com.etec.ingresso.entity.Sala;
import br.com.etec.ingresso.repository.SalaRepository;
import org.junit.jupiter.api.Test;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class SalaControllerTests {
    private final SalaRepository repository = mock(SalaRepository.class);
    private final SalaController controller = new SalaController(repository);

    private Sala sala() {
        Sala sala = new Sala();
        sala.setNome("Sala 1");
        sala.setPreco(10.0);
        return sala;
    }

    @Test
    void validaLimitesNoPostENoPutSemGravar() {
        for (int caso = 0; caso < 7; caso++) {
            Sala sala = sala();
            switch (caso) {
                case 0 -> sala.setNome("a".repeat(255));
                case 1 -> sala.setPreco(5.0);
                case 2 -> sala.setDataExclusao(LocalDateTime.now());
                case 3 -> sala.setPreco(null);
                case 4 -> sala.setNome(null);
                case 5 -> sala.setPreco(Double.NaN);
                case 6 -> sala.setNome("  ");
            }
            assertEquals(400, controller.cadastrar(sala).getStatusCode().value());
            assertEquals(400, controller.atualizar(sala, 1L).getStatusCode().value());
        }
        verifyNoInteractions(repository);
    }

    @Test
    void cadastroAceita254CaracteresEIgnoraIdEnviado() {
        Sala sala = sala();
        sala.setNome("a".repeat(254));
        sala.setPreco(5.01);
        sala.setId(99L);
        when(repository.save(sala)).thenReturn(sala);
        assertEquals(200, controller.cadastrar(sala).getStatusCode().value());
        assertNull(sala.getId());
        verify(repository).save(sala);
    }

    @Test
    void atualizacaoMantemIdDaUrl() {
        Sala existente = sala();
        existente.setId(1L);
        Sala entrada = sala();
        entrada.setId(99L);
        entrada.setNome("Sala nova");
        when(repository.findById(1L)).thenReturn(Optional.of(existente));
        when(repository.save(existente)).thenReturn(existente);
        assertEquals(200, controller.atualizar(entrada, 1L).getStatusCode().value());
        assertEquals(1L, existente.getId());
        assertEquals("Sala nova", existente.getNome());
        verify(repository).save(existente);
    }

    @Test
    void retorna404ParaRegistrosAusentesEListaVazia() {
        when(repository.findAll()).thenReturn(List.of());
        when(repository.findById(1L)).thenReturn(Optional.empty());
        assertEquals(404, controller.listar().getStatusCode().value());
        assertEquals(404, controller.buscarPorId(1L).getStatusCode().value());
        assertEquals(404, controller.atualizar(sala(), 1L).getStatusCode().value());
        assertEquals(404, controller.deletar(1L).getStatusCode().value());
        verify(repository, never()).save(any());
        verify(repository, never()).delete(any());
    }

    @Test
    void listaBuscaEExcluiRegistroExistente() {
        Sala sala = sala();
        when(repository.findAll()).thenReturn(List.of(sala));
        when(repository.findById(1L)).thenReturn(Optional.of(sala));
        assertEquals(201, controller.listar().getStatusCode().value());
        assertSame(sala, controller.buscarPorId(1L).getBody());
        assertEquals(200, controller.deletar(1L).getStatusCode().value());
        verify(repository).delete(sala);
    }
}
